![](banner.jpg)

## EN

This MOD displays all specialists at all merchants except pirates.

As well as 14 unique specialists and items,
as well as 14 cheat specialists and items from the game developers.

1. Merchants, except pirates, have access to all specialists and items, of which there are over 382.

2. These merchants have been given 28 unique specialists and items.

3. Descriptions of unique specialists and items are only available in the English localization,
and my Russian and Ukrainian localization versions.

===============================================================

Unique 14 + 14

Legendary 57

Epic = 115

Rare = 127

Common 68

Uncommon 1

======================================================================

This is an alternative to the "trader-specialists-all" mod.
Use only one of these mods, or the "trader-specialists-cheats" mod
must come after the "trader-specialists-all" mod.

====== Installation Instructions ======

1. Drag the mod into the game folder: Anno 117 - Pax Romana\mods
2. If the mods folder doesn't exist, create it in the game's root directory.

==============================================================

Mod version 3.0 from November 17, 2025


## RU

МОД Показывает всех специалистов у всех торговцев кроме пиратов.
а также 14 уникальных специалистов и предметов,
а также 14 ЧИТерские специалистов и предметов от разработчиков игры

1. У торговцев, кроме пиратов, в ассортименте доступны все Специалисты и Объекты, а их больше 382

2. Этим торговцам добавлены 28 уникальных специалтстов и предметов.

3. Описание уникальных специалистов и предметов, есть только в английской локализации,
и моих версиях Русская и Украинская локализация.

Вы можете неограниченно покупать и использовать любые уникальные предметы и специалисты

==========================================================

Уникальные 14 + 14

Легендарные 57

Эпические = 115

Редкие = 127

Обычные 68

Необычный 1

==========================================================

Это Альтернатива Моду "trader-specialists-all"
Используйте только один из этих модов, или мод "trader-specialists-cheats"
должен идти после мода "trader-specialists-all"

====== Инструкция по установке ======

1. Перетащите мод в папку с игрой: Anno 117 - Pax Romana\mods
2. Если папки mods нет, создайте её в корне игры.

==========================================================

Версия мода 3.0 от 17.11.2025
